# Event's Managment System
This is Web-based prototype for my University Event's Managment System.

